#!/bin/bash
echo "Running Server..."
java -cp bin Server "$@"
