#!/bin/bash
echo "Running Client..."
java -cp bin Client "$@"
